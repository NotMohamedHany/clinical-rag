import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { userApi } from '../api/user';
import { useAuth } from './AuthContext';
import type { NotificationSettings, VoiceSettings } from '../types';

interface VoiceSettingsContextValue {
  voice: VoiceSettings;
  notifications: NotificationSettings;
  setVoice: (v: Partial<VoiceSettings>) => void;
  setNotifications: (n: Partial<NotificationSettings>) => void;
  isReady: boolean;
}

const DEFAULT_VOICE: VoiceSettings = { enabled: true, rate: 1, voiceURI: null, autoPlay: false };
const DEFAULT_NOTIFS: NotificationSettings = { productUpdates: true, chatSummaries: false };

const VoiceSettingsContext = createContext<VoiceSettingsContextValue | undefined>(undefined);

export function VoiceSettingsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [voice, setVoiceState] = useState<VoiceSettings>(DEFAULT_VOICE);
  const [notifications, setNotificationsState] = useState<NotificationSettings>(DEFAULT_NOTIFS);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    if (!user) {
      setVoiceState(DEFAULT_VOICE);
      setNotificationsState(DEFAULT_NOTIFS);
      setIsReady(true);
      return;
    }
    userApi.getPreferences(user.id).then((prefs) => {
      setVoiceState(prefs.voice);
      setNotificationsState(prefs.notifications);
      setIsReady(true);
    });
  }, [user]);

  const persist = (nextVoice: VoiceSettings, nextNotifs: NotificationSettings) => {
    if (user) userApi.savePreferences(user.id, { voice: nextVoice, notifications: nextNotifs });
  };

  const setVoice = (partial: Partial<VoiceSettings>) => {
    setVoiceState((prev) => {
      const next = { ...prev, ...partial };
      persist(next, notifications);
      return next;
    });
  };

  const setNotifications = (partial: Partial<NotificationSettings>) => {
    setNotificationsState((prev) => {
      const next = { ...prev, ...partial };
      persist(voice, next);
      return next;
    });
  };

  return (
    <VoiceSettingsContext.Provider value={{ voice, notifications, setVoice, setNotifications, isReady }}>
      {children}
    </VoiceSettingsContext.Provider>
  );
}

export function useVoiceSettings() {
  const ctx = useContext(VoiceSettingsContext);
  if (!ctx) throw new Error('useVoiceSettings must be used within VoiceSettingsProvider');
  return ctx;
}
