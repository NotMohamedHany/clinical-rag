import { useState, type FormEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { AuthLayout } from '../components/auth/AuthLayout';
import { PasswordField } from '../components/auth/PasswordField';
import { Button } from '../components/common/Button';
import { useAuth } from '../context/AuthContext';
import { isValidEmail } from '../utils/validators';
import { ApiError } from '../api/client';
import { authApi } from '../api/auth';

export function SignInPage() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(true);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const from = (location.state as { from?: string })?.from || '/';

  const validate = () => {
    const next: typeof errors = {};
    if (!isValidEmail(email)) next.email = 'Enter a valid email address.';
    if (!password) next.password = 'Password is required.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setResetSent(false);
    if (!validate()) return;
    setLoading(true);
    try {
      await signIn(email, password);
      navigate(from, { replace: true });
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Unable to sign in. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const onForgotPassword = async () => {
    if (!isValidEmail(email)) {
      setErrors({ email: 'Enter your email above first.' });
      return;
    }
    await authApi.requestPasswordReset(email);
    setResetSent(true);
  };

  return (
    <AuthLayout>
      <h2>Welcome back</h2>
      <p className="auth-sub">Sign in to continue your conversation about digestive health.</p>

      <form className="auth-form" onSubmit={onSubmit} noValidate>
        {formError && <div className="auth-error-banner">{formError}</div>}
        {resetSent && <div className="auth-error-banner" style={{ background: 'var(--brand-soft)', color: 'var(--brand-strong)' }}>Check your inbox for a reset link.</div>}

        <div className="field">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
            className={errors.email ? 'has-error' : ''}
          />
          {errors.email && <span className="field-error">{errors.email}</span>}
        </div>

        <PasswordField
          label="Password"
          value={password}
          onChange={setPassword}
          error={errors.password}
          autoComplete="current-password"
        />

        <div className="auth-row-between">
          <label className="auth-check">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
            Remember me
          </label>
          <button type="button" className="auth-link" style={{ background: 'none', border: 'none', padding: 0 }} onClick={onForgotPassword}>
            Forgot password?
          </button>
        </div>

        <Button type="submit" block loading={loading}>
          Sign in
        </Button>
      </form>

      <div className="auth-foot">
        Don&apos;t have an account? <Link className="auth-link" to="/sign-up">Create one</Link>
      </div>
    </AuthLayout>
  );
}
