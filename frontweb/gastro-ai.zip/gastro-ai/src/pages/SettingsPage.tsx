import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TopBar } from '../components/layout/TopBar';
import { Avatar } from '../components/common/Avatar';
import { Button } from '../components/common/Button';
import { PasswordField } from '../components/auth/PasswordField';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useVoiceSettings } from '../context/VoiceSettingsContext';
import { useToast } from '../context/ToastContext';
import { useSpeechSynthesis } from '../hooks/useSpeechSynthesis';
import { passwordStrengthError } from '../utils/validators';
import { IconMonitor, IconMoon, IconSun } from '../components/common/Icons';

export function SettingsPage() {
  const { user, signOut } = useAuth();
  const { mode, setMode } = useTheme();
  const { voice, setVoice, notifications, setNotifications } = useVoiceSettings();
  const { voices } = useSpeechSynthesis();
  const { push } = useToast();
  const navigate = useNavigate();

  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [pwError, setPwError] = useState<string | null>(null);
  const [savingPw, setSavingPw] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/sign-in', { replace: true });
  };

  const handlePasswordUpdate = async () => {
    setPwError(null);
    if (!currentPw) {
      setPwError('Enter your current password.');
      return;
    }
    const err = passwordStrengthError(newPw);
    if (err) {
      setPwError(err);
      return;
    }
    setSavingPw(true);
    await new Promise((r) => setTimeout(r, 500));
    setSavingPw(false);
    setCurrentPw('');
    setNewPw('');
    push('Password updated.', 'success');
  };

  return (
    <>
      <TopBar title="Settings" />
      <div className="chat-scroll">
        <div className="settings-shell">
          <div className="settings-header">
            <h1>Settings</h1>
            <p>Manage your profile, appearance, and voice preferences.</p>
          </div>

          <div className="settings-card">
            <h3>Profile</h3>
            <p className="settings-card-sub">Your account information.</p>
            <div className="profile-row">
              <Avatar name={user?.name || 'User'} size="lg" />
              <div>
                <div style={{ fontWeight: 600, fontSize: 15 }}>{user?.name}</div>
                <div style={{ fontSize: 13, color: 'var(--ink-muted)' }}>{user?.email}</div>
              </div>
            </div>
          </div>

          <div className="settings-card">
            <h3>Password</h3>
            <p className="settings-card-sub">Update the password used to sign in.</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <PasswordField label="Current password" value={currentPw} onChange={setCurrentPw} autoComplete="current-password" />
              <PasswordField label="New password" value={newPw} onChange={setNewPw} error={pwError} autoComplete="new-password" />
              <div>
                <Button variant="secondary" onClick={handlePasswordUpdate} loading={savingPw}>
                  Update password
                </Button>
              </div>
            </div>
          </div>

          <div className="settings-card">
            <h3>Appearance</h3>
            <p className="settings-card-sub">Choose how Gastro AI looks on your device.</p>
            <div className="theme-switch-group">
              <button className={`theme-switch-opt ${mode === 'light' ? 'active' : ''}`} onClick={() => setMode('light')}>
                <IconSun size={14} /> Light
              </button>
              <button className={`theme-switch-opt ${mode === 'dark' ? 'active' : ''}`} onClick={() => setMode('dark')}>
                <IconMoon size={14} /> Dark
              </button>
              <button className={`theme-switch-opt ${mode === 'system' ? 'active' : ''}`} onClick={() => setMode('system')}>
                <IconMonitor size={14} /> System
              </button>
            </div>
          </div>

          <div className="settings-card">
            <h3>Voice</h3>
            <p className="settings-card-sub">Control how the assistant speaks its responses.</p>

            <div className="settings-row">
              <div>
                <div className="settings-row-label">Voice responses enabled</div>
                <div className="settings-row-desc">Allow AI replies to be read aloud.</div>
              </div>
              <button
                className={`toggle ${voice.enabled ? 'on' : ''}`}
                onClick={() => setVoice({ enabled: !voice.enabled })}
                aria-label="Toggle voice responses"
              >
                <span className="toggle-knob" />
              </button>
            </div>

            <div className="settings-row">
              <div>
                <div className="settings-row-label">Auto-play responses</div>
                <div className="settings-row-desc">Speak new AI messages automatically.</div>
              </div>
              <button
                className={`toggle ${voice.autoPlay ? 'on' : ''}`}
                onClick={() => setVoice({ autoPlay: !voice.autoPlay })}
                aria-label="Toggle auto-play"
              >
                <span className="toggle-knob" />
              </button>
            </div>

            <div className="settings-row">
              <div>
                <div className="settings-row-label">Voice</div>
                <div className="settings-row-desc">Which system voice to use for speech.</div>
              </div>
              <select
                className="select-input"
                value={voice.voiceURI || ''}
                onChange={(e) => setVoice({ voiceURI: e.target.value || null })}
              >
                <option value="">System default</option>
                {voices.map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>
                    {v.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="settings-row">
              <div>
                <div className="settings-row-label">Speed</div>
                <div className="settings-row-desc">{voice.rate.toFixed(1)}x</div>
              </div>
              <input
                className="range-input"
                type="range"
                min="0.5"
                max="1.5"
                step="0.1"
                value={voice.rate}
                onChange={(e) => setVoice({ rate: parseFloat(e.target.value) })}
              />
            </div>
          </div>

          <div className="settings-card">
            <h3>Notifications</h3>
            <p className="settings-card-sub">Choose what Gastro AI can notify you about.</p>
            <div className="settings-row">
              <div>
                <div className="settings-row-label">Product updates</div>
                <div className="settings-row-desc">New features and improvements.</div>
              </div>
              <button
                className={`toggle ${notifications.productUpdates ? 'on' : ''}`}
                onClick={() => setNotifications({ productUpdates: !notifications.productUpdates })}
              >
                <span className="toggle-knob" />
              </button>
            </div>
            <div className="settings-row">
              <div>
                <div className="settings-row-label">Chat summaries</div>
                <div className="settings-row-desc">Weekly digest of your conversations.</div>
              </div>
              <button
                className={`toggle ${notifications.chatSummaries ? 'on' : ''}`}
                onClick={() => setNotifications({ chatSummaries: !notifications.chatSummaries })}
              >
                <span className="toggle-knob" />
              </button>
            </div>
          </div>

          <Button variant="secondary" onClick={handleSignOut}>
            Log out
          </Button>
        </div>
      </div>
    </>
  );
}
