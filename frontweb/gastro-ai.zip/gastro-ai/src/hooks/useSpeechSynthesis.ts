import { useCallback, useEffect, useRef, useState } from 'react';

export const isSpeechSynthesisSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

export function useSpeechSynthesis() {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (!isSpeechSynthesisSupported) return;
    const loadVoices = () => setVoices(window.speechSynthesis.getVoices());
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  const speak = useCallback(
    (id: string, text: string, opts: { rate?: number; voiceURI?: string | null } = {}, onEnd?: () => void) => {
      if (!isSpeechSynthesisSupported) return;
      window.speechSynthesis.cancel();
      // Strip markdown syntax for cleaner speech.
      const clean = text
        .replace(/[#*_`>]/g, '')
        .replace(/\[(.*?)\]\(.*?\)/g, '$1')
        .replace(/\n+/g, '. ');
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.rate = opts.rate ?? 1;
      if (opts.voiceURI) {
        const voice = voices.find((v) => v.voiceURI === opts.voiceURI);
        if (voice) utterance.voice = voice;
      }
      utterance.onend = () => {
        setSpeakingId(null);
        setIsPaused(false);
        onEnd?.();
      };
      utterance.onerror = () => {
        setSpeakingId(null);
        setIsPaused(false);
      };
      utteranceRef.current = utterance;
      setSpeakingId(id);
      setIsPaused(false);
      window.speechSynthesis.speak(utterance);
    },
    [voices]
  );

  const pause = useCallback(() => {
    if (!isSpeechSynthesisSupported) return;
    window.speechSynthesis.pause();
    setIsPaused(true);
  }, []);

  const resume = useCallback(() => {
    if (!isSpeechSynthesisSupported) return;
    window.speechSynthesis.resume();
    setIsPaused(false);
  }, []);

  const stop = useCallback(() => {
    if (!isSpeechSynthesisSupported) return;
    window.speechSynthesis.cancel();
    setSpeakingId(null);
    setIsPaused(false);
  }, []);

  return { voices, speak, pause, resume, stop, speakingId, isPaused, isSupported: isSpeechSynthesisSupported };
}
