type OrbStatus = 'idle' | 'listening' | 'thinking' | 'speaking';

export function VoiceOrb({ status }: { status: OrbStatus }) {
  const orbClass = status === 'listening' ? 'listening' : status === 'speaking' ? 'speaking' : '';
  return (
    <div className="voice-orb-wrap">
      <div className="voice-orb-ring r2" />
      <div className="voice-orb-ring r3" />
      <div className={`voice-orb ${orbClass}`} />
    </div>
  );
}
