import { useEffect, useRef, useState } from 'react';
import { VoiceOrb } from './VoiceOrb';
import { useChat } from '../../context/ChatContext';
import { useVoiceSettings } from '../../context/VoiceSettingsContext';
import { useSpeechRecognition, isSpeechRecognitionSupported } from '../../hooks/useSpeechRecognition';
import { useSpeechSynthesis, isSpeechSynthesisSupported } from '../../hooks/useSpeechSynthesis';
import { chatApi } from '../../api/chat';
import { useToast } from '../../context/ToastContext';
import { IconMic, IconVolumeMute, IconX } from '../common/Icons';

type Status = 'idle' | 'listening' | 'thinking' | 'speaking' | 'muted';

interface VoiceConversationModeProps {
  onClose: () => void;
}

export function VoiceConversationMode({ onClose }: VoiceConversationModeProps) {
  const { activeId, activeConversation, sendMessage } = useChat();
  const { voice } = useVoiceSettings();
  const { push } = useToast();
  const [status, setStatus] = useState<Status>('idle');
  const [caption, setCaption] = useState('Tap the microphone to start talking.');
  const mutedRef = useRef(false);
  const activeIdRef = useRef(activeId);

  useEffect(() => {
    activeIdRef.current = activeId;
  }, [activeId]);

  const { speak, stop: stopSpeaking } = useSpeechSynthesis();

  const handleFinalTranscript = async (transcript: string) => {
    if (!transcript.trim()) {
      if (!mutedRef.current) start();
      return;
    }
    setCaption(transcript);
    setStatus('thinking');
    try {
      const convoId = activeIdRef.current || 'voice-session';
      const res = await chatApi.sendMessage({ message: transcript, conversation_id: convoId });
      // Persist to conversation history in the background.
      sendMessage(transcript).catch(() => undefined);
      const cleanCaption = res.answer.replace(/[#*`]/g, '').split('\n')[0].slice(0, 220);
      setCaption(cleanCaption);
      setStatus('speaking');
      speak('voice-mode', res.answer, { rate: voice.rate, voiceURI: voice.voiceURI }, () => {
        if (!mutedRef.current) {
          setStatus('listening');
          start();
        } else {
          setStatus('muted');
        }
      });
    } catch {
      setCaption('Something went wrong. Please try again.');
      setStatus('idle');
    }
  };

  const { isListening, interimTranscript, start, stop, error } = useSpeechRecognition({
    onFinalResult: handleFinalTranscript,
  });

  useEffect(() => {
    if (!isSpeechRecognitionSupported) {
      push('Voice conversation needs microphone support (try Chrome or Edge).', 'error');
    }
    if (isSpeechRecognitionSupported) {
      setStatus('listening');
      start();
    }
    return () => {
      stop();
      stopSpeaking();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (error) setCaption('I had trouble hearing that — tap the mic to try again.');
  }, [error]);

  useEffect(() => {
    if (isListening && interimTranscript) setCaption(interimTranscript);
  }, [interimTranscript, isListening]);

  const handleToggleMute = () => {
    if (mutedRef.current) {
      mutedRef.current = false;
      setStatus('listening');
      start();
    } else {
      mutedRef.current = true;
      stop();
      stopSpeaking();
      setStatus('muted');
      setCaption('Muted. Tap the mic to resume.');
    }
  };

  const handleMicTap = () => {
    if (status === 'muted' || status === 'idle') {
      mutedRef.current = false;
      setStatus('listening');
      start();
    }
  };

  const statusLabel =
    status === 'listening'
      ? 'Listening'
      : status === 'thinking'
      ? 'Thinking'
      : status === 'speaking'
      ? 'Speaking'
      : status === 'muted'
      ? 'Muted'
      : 'Ready';

  return (
    <div className="voice-mode">
      <div className="voice-mode-top">
        <div className="voice-mode-status">{statusLabel} · {activeConversation?.title || 'New voice session'}</div>
        <div className="voice-mode-caption">{caption}</div>
      </div>

      <div onClick={handleMicTap} style={{ cursor: status === 'muted' || status === 'idle' ? 'pointer' : 'default' }}>
        <VoiceOrb status={status === 'muted' || status === 'idle' ? 'idle' : status} />
      </div>

      <div className="voice-mode-bottom">
        <button
          className={`voice-round-btn ${status === 'muted' ? 'active' : ''}`}
          onClick={handleToggleMute}
          aria-label={status === 'muted' ? 'Unmute' : 'Mute'}
        >
          {status === 'muted' ? <IconVolumeMute size={22} /> : <IconMic size={22} />}
        </button>
        <button
          className="voice-round-btn end"
          onClick={() => {
            stop();
            stopSpeaking();
            onClose();
          }}
          aria-label="End conversation"
        >
          <IconX size={24} />
        </button>
      </div>
    </div>
  );
}

export const voiceModeSupported = isSpeechRecognitionSupported && isSpeechSynthesisSupported;
