import { USE_MOCK, mockDelay, request } from './client';
import { findMockAnswer } from './mockData';
import type { ChatRequest, ChatResponse } from '../types';

export const chatApi = {
  /**
   * Sends a user message + conversation id to the RAG backend and returns
   * the generated answer along with the retrieved sources. When no backend
   * is configured, falls back to a small local knowledge lookup so the UI
   * can still be demonstrated.
   */
  async sendMessage(payload: ChatRequest): Promise<ChatResponse> {
    if (USE_MOCK) {
      await mockDelay(900 + Math.random() * 600);
      const { answer, sources } = findMockAnswer(payload.message);
      return { answer, sources };
    }
    return request<ChatResponse>('/api/chat', { method: 'POST', body: payload });
  },
};
