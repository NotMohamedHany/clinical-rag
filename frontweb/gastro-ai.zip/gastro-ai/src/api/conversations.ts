import { USE_MOCK, mockDelay, request } from './client';
import type { Conversation } from '../types';

const STORE_KEY = 'gastro_ai_mock_conversations';

function readStore(): Record<string, Conversation[]> {
  try {
    return JSON.parse(localStorage.getItem(STORE_KEY) || '{}');
  } catch {
    return {};
  }
}

function writeStore(store: Record<string, Conversation[]>) {
  localStorage.setItem(STORE_KEY, JSON.stringify(store));
}

function userKey(userId: string) {
  return userId;
}

export const conversationsApi = {
  async list(userId: string): Promise<Conversation[]> {
    if (USE_MOCK) {
      await mockDelay(250);
      const store = readStore();
      return (store[userKey(userId)] || []).sort(
        (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      );
    }
    return request<Conversation[]>('/api/conversations');
  },

  async create(userId: string, title = 'New conversation'): Promise<Conversation> {
    if (USE_MOCK) {
      await mockDelay(150);
      const store = readStore();
      const list = store[userKey(userId)] || [];
      const convo: Conversation = {
        id: crypto.randomUUID(),
        title,
        messages: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      store[userKey(userId)] = [convo, ...list];
      writeStore(store);
      return convo;
    }
    return request<Conversation>('/api/conversations', { method: 'POST', body: { title } });
  },

  async update(userId: string, conversation: Conversation): Promise<Conversation> {
    if (USE_MOCK) {
      await mockDelay(80);
      const store = readStore();
      const list = store[userKey(userId)] || [];
      const idx = list.findIndex((c) => c.id === conversation.id);
      const updated = { ...conversation, updatedAt: new Date().toISOString() };
      if (idx >= 0) list[idx] = updated;
      else list.unshift(updated);
      store[userKey(userId)] = list;
      writeStore(store);
      return updated;
    }
    return request<Conversation>(`/api/conversations/${conversation.id}`, {
      method: 'PUT',
      body: conversation,
    });
  },

  async rename(userId: string, id: string, title: string): Promise<void> {
    if (USE_MOCK) {
      await mockDelay(120);
      const store = readStore();
      const list = store[userKey(userId)] || [];
      const idx = list.findIndex((c) => c.id === id);
      if (idx >= 0) {
        list[idx] = { ...list[idx], title, updatedAt: new Date().toISOString() };
        store[userKey(userId)] = list;
        writeStore(store);
      }
      return;
    }
    await request(`/api/conversations/${id}`, { method: 'PATCH', body: { title } });
  },

  async remove(userId: string, id: string): Promise<void> {
    if (USE_MOCK) {
      await mockDelay(120);
      const store = readStore();
      store[userKey(userId)] = (store[userKey(userId)] || []).filter((c) => c.id !== id);
      writeStore(store);
      return;
    }
    await request(`/api/conversations/${id}`, { method: 'DELETE' });
  },
};
