import { USE_MOCK, request } from './client';

/**
 * Structured so a real TTS backend (e.g. ElevenLabs, Azure, or a custom
 * FastAPI /api/voice/speak endpoint returning audio bytes) can be dropped
 * in later. Until then, the app uses the browser's Web Speech API directly
 * (see hooks/useSpeechSynthesis and hooks/useSpeechRecognition) and never
 * calls this endpoint.
 */
export const voiceApi = {
  async synthesize(text: string, voiceURI?: string | null): Promise<Blob | null> {
    if (USE_MOCK) {
      // No server-side TTS in the mock environment — the caller should use
      // the Web Speech API fallback instead.
      return null;
    }
    const res = await fetch(`${import.meta.env.VITE_API_URL}/api/voice/speak`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, voice: voiceURI }),
    });
    if (!res.ok) throw new Error('Voice synthesis failed');
    return res.blob();
  },

  async transcribe(audio: Blob): Promise<string> {
    if (USE_MOCK) return '';
    const form = new FormData();
    form.append('audio', audio);
    return request<{ text: string }>('/api/voice/transcribe', {
      method: 'POST',
      body: form as unknown as Record<string, unknown>,
    }).then((r) => r.text);
  },
};
