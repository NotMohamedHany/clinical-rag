const API_URL = import.meta.env.VITE_API_URL || '';
const FORCE_MOCK = import.meta.env.VITE_USE_MOCK_API === 'true' || !API_URL;

export const USE_MOCK = FORCE_MOCK;

const TOKEN_KEY = 'gastro_ai_token';

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 500) {
    super(message);
    this.status = status;
  }
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  body?: unknown;
  signal?: AbortSignal;
}

/**
 * Thin wrapper around fetch that targets the real backend (FastAPI/Flask).
 * Every domain service (auth, chat, conversations, voice, user) checks
 * `USE_MOCK` first and only calls this when a real backend is configured,
 * so the UI never hard-depends on network availability during development
 * or demos.
 */
export async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    method: options.method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...(getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
    signal: options.signal,
  });

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const data = await res.json();
      message = data.message || message;
    } catch {
      /* noop */
    }
    throw new ApiError(message, res.status);
  }

  if (res.status === 204) return undefined as T;
  return res.json();
}

/** Simulated network latency so mock responses feel realistic in the UI. */
export function mockDelay(ms = 500): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
